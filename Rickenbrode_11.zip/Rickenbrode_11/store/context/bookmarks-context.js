import { createContext, useState } from 'react';

export const BookmarksContext = createContext({
  bookmarkedIds: [],
  addBookmark: (id) => {},
  removeBookmark: (id) => {},
});

function BookmarksContextProvider({ children }) {
  const [bookmarkedIds, setBookmarkedIds] = useState([]);

  function addBookmark(id) {
    setBookmarkedIds((prev) => [...prev, id]);
  }

  function removeBookmark(id) {
    setBookmarkedIds((prev) => prev.filter((bookmarkId) => bookmarkId !== id));
  }

  const value = {
    bookmarkedIds,
    addBookmark,
    removeBookmark,
  };

  return (
    <BookmarksContext.Provider value={value}>
      {children}
    </BookmarksContext.Provider>
  );
}

export default BookmarksContextProvider;
