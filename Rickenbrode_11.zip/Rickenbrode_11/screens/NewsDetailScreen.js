import React, { useLayoutEffect, useContext } from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import NEWS_DATA from '../data/dummy-data';
import { BookmarksContext } from '../store/context/bookmarks-context';

function BookmarkButton({ bookmarked, onPress }) {
  return (
    <Ionicons
      name={bookmarked ? 'bookmark' : 'bookmark-outline'}
      size={24}
      color="#fff"
      onPress={onPress}
    />
  );
}

function NewsDetailScreen({ route, navigation }) {
  const bookmarksCtx = useContext(BookmarksContext);
  const { newsId } = route.params;

  const isBookmarked = bookmarksCtx.bookmarkedIds.includes(newsId);

  const selectedNews = NEWS_DATA.find((item) => item.id === newsId);

  function toggleBookmark() {
    if (isBookmarked) {
      bookmarksCtx.removeBookmark(newsId);
    } else {
      bookmarksCtx.addBookmark(newsId);
    }
  }

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <BookmarkButton
          bookmarked={isBookmarked}
          onPress={toggleBookmark}
        />
      ),
    });
  }, [navigation, isBookmarked]);

  if (!selectedNews) {
    return (
      <View style={styles.centered}>
        <Text style={styles.missing}>News article not found.</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.root} contentContainerStyle={styles.contentContainer}>
      <Image source={{ uri: selectedNews.imageUrl }} style={styles.image} />
      <View style={styles.detailCard}>
        <Text style={styles.headline}>{selectedNews.headline}</Text>
        <Text style={styles.meta}>{selectedNews.date}</Text>
        <Text style={styles.meta}>Author: {selectedNews.author}</Text>
        <Text style={styles.meta}>Agency: {selectedNews.agency}</Text>
        <Text style={styles.description}>{selectedNews.description}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#fff9f0',
  },
  contentContainer: {
    paddingBottom: 24,
  },
  centered: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff9f0',
  },
  missing: {
    color: '#1f3a5f',
    fontSize: 17,
  },
  image: {
    width: '100%',
    height: 240,
  },
  detailCard: {
    marginTop: -18,
    marginHorizontal: 14,
    padding: 16,
    borderRadius: 14,
    backgroundColor: '#ffffff',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.16,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
  },
  headline: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1a3558',
    marginBottom: 12,
  },
  meta: {
    fontSize: 14,
    color: '#4f5f77',
    marginBottom: 4,
  },
  description: {
    marginTop: 14,
    fontSize: 16,
    lineHeight: 23,
    color: '#2a3f5f',
  },
});

export default NewsDetailScreen;
