import React, { useContext } from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';
import { BookmarksContext } from '../store/context/bookmarks-context';
import NEWS_DATA from '../data/dummy-data';
import ListItem from '../components/ListItem';

function BookmarkedNewsScreen({ navigation }) {
  const bookmarksCtx = useContext(BookmarksContext);

  const bookmarkedItems = NEWS_DATA.filter((item) =>
    bookmarksCtx.bookmarkedIds.includes(item.id)
  );

  if (bookmarkedItems.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyTitle}>No Bookmarks Yet</Text>
        <Text style={styles.emptySubtitle}>
          Articles you bookmark will appear here.
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      data={bookmarkedItems}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <ListItem
          item={item}
          onPress={() => navigation.navigate('News Detail', { newsId: item.id })}
        />
      )}
      contentContainerStyle={styles.listContent}
    />
  );
}

const styles = StyleSheet.create({
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff9f0',
    padding: 20,
  },
  emptyTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#1f3a5f',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 16,
    color: '#4e5f78',
    textAlign: 'center',
  },
  listContent: {
    paddingVertical: 12,
    backgroundColor: '#fff9f0',
  },
});

export default BookmarkedNewsScreen;

