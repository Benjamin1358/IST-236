import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import DestinationsScreen from '../screens/DestinationsScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#1a1a2e',
          },
          headerTintColor: '#f5f5f5',
          headerTitleStyle: {
            fontFamily: 'Poppins-Bold',
            fontSize: 20,
          },
          contentStyle: {
            backgroundColor: '#f0f4f8',
          },
        }}
      >
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ title: 'Vacation Destinations' }}
        />
        <Stack.Screen
          name="Destinations"
          component={DestinationsScreen}
          options={({ route }) => ({ title: route.params?.country?.name ?? 'Destinations' })}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
