export default class Country {
  constructor(id, name, backgroundColor, imageUrl) {
    this.id = id;
    this.name = name;
    this.backgroundColor = backgroundColor;
    this.imageUrl = imageUrl;
  }
}
