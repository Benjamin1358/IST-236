import React from 'react';
import { StyleSheet, Text, TouchableOpacity, Image, View } from 'react-native';

export default function DestinationItem({ destination, onPress }) {
  const stars = '★'.repeat(Math.floor(destination.averageRating)) +
    (destination.averageRating % 1 >= 0.5 ? '½' : '') +
    '☆'.repeat(5 - Math.ceil(destination.averageRating));

  return (
    <TouchableOpacity style={styles.card} onPress={onPress} activeOpacity={0.88}>
      <Image source={{ uri: destination.imageUrl }} style={styles.image} />
      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={1}>{destination.name}</Text>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Avg. Cost</Text>
          <Text style={styles.detailValue}>${destination.averageCost.toLocaleString()}</Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Founded</Text>
          <Text style={styles.detailValue}>
            {destination.yearFounded < 0
              ? `${Math.abs(destination.yearFounded)} BC`
              : destination.yearFounded === 0
              ? 'Prehistoric'
              : destination.yearFounded}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Rating</Text>
          <View style={styles.ratingRow}>
            <Text style={styles.ratingStars}>{stars}</Text>
            <Text style={styles.ratingNumber}>{destination.averageRating.toFixed(1)}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 14,
    marginHorizontal: 16,
    marginVertical: 8,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 5,
  },
  image: {
    width: 110,
    height: 130,
    resizeMode: 'cover',
  },
  info: {
    flex: 1,
    padding: 12,
    justifyContent: 'space-between',
  },
  name: {
    fontFamily: 'Poppins-Bold',
    fontSize: 15,
    color: '#1a1a2e',
    marginBottom: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 2,
  },
  detailLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    color: '#6b7280',
  },
  detailValue: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 12,
    color: '#1a1a2e',
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingStars: {
    fontSize: 11,
    color: '#f59e0b',
  },
  ratingNumber: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 12,
    color: '#1a1a2e',
  },
});
