import React from 'react';
import {
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  Image,
  View,
  ScrollView,
  SafeAreaView,
} from 'react-native';

export default function DestinationModal({ destination, visible, onClose }) {
  if (!destination) return null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <SafeAreaView style={styles.container}>
        <Image source={{ uri: destination.imageUrl }} style={styles.image} />
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          <Text style={styles.name}>{destination.name}</Text>

          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Text style={styles.statLabel}>Avg. Cost</Text>
              <Text style={styles.statValue}>${destination.averageCost.toLocaleString()}</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.stat}>
              <Text style={styles.statLabel}>Founded</Text>
              <Text style={styles.statValue}>
                {destination.yearFounded < 0
                  ? `${Math.abs(destination.yearFounded)} BC`
                  : destination.yearFounded === 0
                  ? 'Prehistoric'
                  : destination.yearFounded}
              </Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.stat}>
              <Text style={styles.statLabel}>Rating</Text>
              <Text style={styles.statValue}>⭐ {destination.averageRating.toFixed(1)}</Text>
            </View>
          </View>

          <Text style={styles.descriptionHeader}>About</Text>
          <Text style={styles.description}>{destination.description}</Text>
        </ScrollView>

        <View style={styles.footer}>
          <TouchableOpacity style={styles.closeButton} onPress={onClose} activeOpacity={0.8}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  image: {
    width: '100%',
    height: 280,
    resizeMode: 'cover',
  },
  content: {
    flex: 1,
    backgroundColor: '#f0f4f8',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    marginTop: -20,
    paddingHorizontal: 20,
    paddingTop: 24,
  },
  name: {
    fontFamily: 'Poppins-Bold',
    fontSize: 24,
    color: '#1a1a2e',
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: 'row',
    backgroundColor: '#1a1a2e',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 12,
    marginBottom: 24,
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  stat: {
    alignItems: 'center',
    flex: 1,
  },
  statDivider: {
    width: 1,
    height: 36,
    backgroundColor: '#374151',
  },
  statLabel: {
    fontFamily: 'Poppins-Regular',
    fontSize: 11,
    color: '#9ca3af',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  statValue: {
    fontFamily: 'Poppins-Bold',
    fontSize: 14,
    color: '#ffffff',
  },
  descriptionHeader: {
    fontFamily: 'Poppins-Bold',
    fontSize: 18,
    color: '#1a1a2e',
    marginBottom: 10,
  },
  description: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    color: '#374151',
    lineHeight: 22,
    marginBottom: 24,
  },
  footer: {
    backgroundColor: '#f0f4f8',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  closeButton: {
    backgroundColor: '#1a1a2e',
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
  },
  closeButtonText: {
    fontFamily: 'Poppins-Bold',
    fontSize: 16,
    color: '#ffffff',
    letterSpacing: 0.5,
  },
});
