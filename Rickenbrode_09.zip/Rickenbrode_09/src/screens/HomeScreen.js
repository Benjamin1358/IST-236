import React from 'react';
import { StyleSheet, FlatList, View, Text, SafeAreaView } from 'react-native';
import { COUNTRIES } from '../data/dummyData';
import CountryTile from '../components/CountryTile';

export default function HomeScreen({ navigation }) {
  function handleCountryPress(country) {
    navigation.navigate('Destinations', { country });
  }

  function renderItem({ item }) {
    return (
      <CountryTile
        country={item}
        onPress={() => handleCountryPress(item)}
      />
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.subtitle}>Explore the World</Text>
        <Text style={styles.tagline}>Tap a country to discover destinations</Text>
      </View>
      <FlatList
        data={COUNTRIES}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        numColumns={2}
        contentContainerStyle={styles.grid}
        showsVerticalScrollIndicator={false}
        columnWrapperStyle={styles.row}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f8',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  subtitle: {
    fontFamily: 'Poppins-Bold',
    fontSize: 22,
    color: '#1a1a2e',
  },
  tagline: {
    fontFamily: 'Poppins-Regular',
    fontSize: 13,
    color: '#6b7280',
    marginTop: 2,
  },
  grid: {
    paddingHorizontal: 8,
    paddingBottom: 24,
    paddingTop: 8,
  },
  row: {
    justifyContent: 'space-between',
  },
});
