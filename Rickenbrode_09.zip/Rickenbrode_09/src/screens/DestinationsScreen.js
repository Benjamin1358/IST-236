import React, { useState } from 'react';
import { StyleSheet, FlatList, View, Text, SafeAreaView } from 'react-native';
import { DESTINATIONS } from '../data/dummyData';
import DestinationItem from '../components/DestinationItem';
import DestinationModal from '../components/DestinationModal';

export default function DestinationsScreen({ route }) {
  const { country } = route.params;
  const [selectedDestination, setSelectedDestination] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const countryDestinations = DESTINATIONS.filter(
    (dest) => dest.countryId === country.id
  );

  function handleDestinationPress(destination) {
    setSelectedDestination(destination);
    setModalVisible(true);
  }

  function handleCloseModal() {
    setModalVisible(false);
    setSelectedDestination(null);
  }

  function renderItem({ item }) {
    return (
      <DestinationItem
        destination={item}
        onPress={() => handleDestinationPress(item)}
      />
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Top Destinations</Text>
        <Text style={styles.subtitle}>
          {countryDestinations.length} place{countryDestinations.length !== 1 ? 's' : ''} to explore in {country.name}
        </Text>
      </View>

      <FlatList
        data={countryDestinations}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No destinations found.</Text>
          </View>
        }
      />

      <DestinationModal
        destination={selectedDestination}
        visible={modalVisible}
        onClose={handleCloseModal}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f8',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 8,
  },
  title: {
    fontFamily: 'Poppins-Bold',
    fontSize: 22,
    color: '#1a1a2e',
  },
  subtitle: {
    fontFamily: 'Poppins-Regular',
    fontSize: 13,
    color: '#6b7280',
    marginTop: 2,
  },
  list: {
    paddingVertical: 8,
    paddingBottom: 24,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 60,
  },
  emptyText: {
    fontFamily: 'Poppins-Regular',
    fontSize: 16,
    color: '#9ca3af',
  },
});
