import Country from '../models/Country';
import Destination from '../models/Destination';

export const COUNTRIES = [
  new Country(
    '1',
    'France',
    '#003189',
    'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=400&auto=format'
  ),
  new Country(
    '2',
    'Japan',
    '#BC002D',
    'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&auto=format'
  ),
  new Country(
    '3',
    'Italy',
    '#009246',
    'https://images.unsplash.com/photo-1525874684015-58379d421a52?w=400&auto=format'
  ),
  new Country(
    '4',
    'United States',
    '#B22234',
    'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?w=400&auto=format'
  ),
  new Country(
    '5',
    'Australia',
    '#00008B',
    'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=400&auto=format'
  ),
  new Country(
    '6',
    'Brazil',
    '#009C3B',
    'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=400&auto=format'
  ),
  new Country(
    '7',
    'Greece',
    '#0D5EAF',
    'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=400&auto=format'
  ),
  new Country(
    '8',
    'Thailand',
    '#A51931',
    'https://images.unsplash.com/photo-1528181304800-259b08848526?w=400&auto=format'
  ),
  new Country(
    '9',
    'Spain',
    '#AA151B',
    'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=400&auto=format'
  ),
  new Country(
    '10',
    'Canada',
    '#C8102E',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&auto=format'
  ),
  new Country(
    '11',
    'Mexico',
    '#006847',
    'https://images.unsplash.com/photo-1518638150340-f706e86654de?w=400&auto=format'
  ),
];

export const DESTINATIONS = [
  // France
  new Destination(
    '1',
    '1',
    'Eiffel Tower',
    2500,
    1889,
    4.8,
    'The Eiffel Tower is a wrought-iron lattice tower on the Champ de Mars in Paris, France. Constructed from 1887 to 1889 as the centerpiece of the 1889 World\'s Fair, it has become a global cultural icon of France and one of the most recognizable structures in the world. Standing 330 meters tall, over 7 million people visit the tower each year.',
    'https://images.unsplash.com/photo-1543349689-9a4d426bee8e?w=600&auto=format'
  ),
  new Destination(
    '2',
    '1',
    'Palace of Versailles',
    1800,
    1661,
    4.7,
    'The Palace of Versailles is a royal château in Versailles, in the Île-de-France region of France. It was the principal royal residence of France from 1682, under Louis XIV, until the start of the French Revolution in 1789. With its grand Hall of Mirrors, stunning gardens, and opulent royal apartments, it remains one of the most spectacular palaces ever built.',
    'https://images.unsplash.com/photo-1591018533408-edc1dc0be51e?w=600&auto=format'
  ),
  new Destination(
    '3',
    '1',
    'Mont Saint-Michel',
    1600,
    708,
    4.6,
    'Mont Saint-Michel is a tidal island and mainland commune in Normandy, France. The island has been inhabited since prehistoric times and has a rich history spanning over 1,000 years. The stunning medieval abbey perched atop the rocky island is surrounded by water at high tide, creating one of the most spectacular and recognized sites in France.',
    'https://images.unsplash.com/photo-1589402081478-e48e4d9d1d3f?w=600&auto=format'
  ),

  // Japan
  new Destination(
    '4',
    '2',
    'Mount Fuji',
    2200,
    0,
    4.9,
    'Mount Fuji is the highest volcano in Japan at 3,776 meters and an active stratovolcano that last erupted in 1707–08. A well-known symbol of Japan, it is frequently depicted in art and photographs. Mount Fuji is one of Japan\'s "Three Holy Mountains" and is listed as a UNESCO World Heritage Site. It attracts over 300,000 climbers annually during the climbing season.',
    'https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=600&auto=format'
  ),
  new Destination(
    '5',
    '2',
    'Kyoto Temples',
    1900,
    794,
    4.8,
    'Kyoto served as the imperial capital of Japan for over a millennium and is now renowned worldwide for its classical Buddhist temples, gardens, imperial palaces, Shinto shrines, and traditional wooden houses. With over 1,600 Buddhist temples and 400 Shinto shrines, Kyoto is a cultural treasure trove and was listed as a UNESCO World Heritage Site in 1994.',
    'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=600&auto=format'
  ),
  new Destination(
    '6',
    '2',
    'Tokyo Tower',
    2800,
    1958,
    4.6,
    'Tokyo Tower is a communications and observation tower in the Shiba-koen district of Minato, Tokyo, Japan. At 332.9 meters, it is the second-tallest structure in Japan. The tower is an Eiffel Tower-inspired lattice tower that serves as a landmark of modern Tokyo, offering breathtaking views of the sprawling metropolitan city and, on clear days, Mount Fuji.',
    'https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?w=600&auto=format'
  ),

  // Italy
  new Destination(
    '7',
    '3',
    'Colosseum',
    2300,
    70,
    4.9,
    'The Colosseum, also known as the Flavian Amphitheatre, is an oval amphitheatre in the centre of Rome. Built of travertine limestone, tuff, and brick-faced concrete, it is the largest ancient amphitheatre ever built and is still the largest standing amphitheatre in the world. It could hold between 50,000 and 80,000 spectators and was used for gladiatorial contests and public spectacles.',
    'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=600&auto=format'
  ),
  new Destination(
    '8',
    '3',
    'Venice Canals',
    2700,
    421,
    4.8,
    'Venice is a city in northeastern Italy and the capital of the Veneto region. It is built on a group of 118 small islands separated by canals and linked by over 400 bridges. The city is renowned for the beauty of its setting, its architecture, and its artworks. Famous for its gondola rides, the Grand Canal, and its unique character as a car-free historic center, Venice is a UNESCO World Heritage Site.',
    'https://images.unsplash.com/photo-1514890547357-a9ee288728e0?w=600&auto=format'
  ),

  // United States
  new Destination(
    '9',
    '4',
    'Grand Canyon',
    1400,
    0,
    4.9,
    'The Grand Canyon is a steep-sided canyon carved by the Colorado River in Arizona. It is 277 miles long, up to 18 miles wide, and attains a depth of over a mile. The Grand Canyon is one of the world\'s great natural wonders, offering dramatic scenery, diverse plant and animal life, and a unique record of geological history spanning two billion years.',
    'https://images.unsplash.com/photo-1474044159687-1ee9f3a51722?w=600&auto=format'
  ),
  new Destination(
    '10',
    '4',
    'New York City',
    3200,
    1624,
    4.7,
    'New York City comprises 5 boroughs sitting where the Hudson River meets the Atlantic Ocean. The most populous city in the US, it is home to iconic landmarks such as the Statue of Liberty, Empire State Building, and Central Park. New York is the world\'s leading financial center and a global hub for art, culture, fashion, and cuisine, attracting over 60 million visitors per year.',
    'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&auto=format'
  ),

  // Australia
  new Destination(
    '11',
    '5',
    'Sydney Opera House',
    2100,
    1973,
    4.8,
    'The Sydney Opera House is a multi-venue performing arts centre in Sydney. Designed by Danish architect Jørn Utzon, the building was formally opened on 20 October 1973. Popularly regarded as one of the 20th century\'s greatest buildings and a masterpiece of architecture, the Opera House was listed as a UNESCO World Heritage Site in 2007. It hosts over 1,500 performances annually.',
    'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=600&auto=format'
  ),
  new Destination(
    '12',
    '5',
    'Great Barrier Reef',
    2900,
    0,
    4.9,
    'The Great Barrier Reef is the world\'s largest coral reef system, composed of over 2,900 individual reefs and 900 islands stretching for over 2,300 kilometers off the coast of Queensland, Australia. It supports an extraordinary diversity of life and was declared a UNESCO World Heritage Site in 1981. It can be seen from outer space and is considered one of the seven natural wonders of the world.',
    'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=600&auto=format'
  ),

  // Brazil
  new Destination(
    '13',
    '6',
    'Christ the Redeemer',
    1700,
    1931,
    4.8,
    'Christ the Redeemer is an Art Deco statue of Jesus Christ in Rio de Janeiro, Brazil. Standing 30 meters tall atop the 710-meter Corcovado mountain, it overlooks the spectacular city below. The statue has become a cultural icon of both Christianity and Brazil and is one of the New Seven Wonders of the World. Its outstretched arms span 28 meters and it weighs 635 metric tons.',
    'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=600&auto=format'
  ),
  new Destination(
    '14',
    '6',
    'Amazon Rainforest',
    2400,
    0,
    4.7,
    'The Amazon rainforest is a moist broadleaf tropical rainforest in the Amazon biome that covers most of the Amazon basin of South America. This basin encompasses 7,000,000 km² of which 5,500,000 km² are covered by the rainforest. The region represents over half of the planet\'s remaining rainforests and comprises the largest and most biodiverse tract of tropical rainforest in the world.',
    'https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=600&auto=format'
  ),

  // Greece
  new Destination(
    '15',
    '7',
    'Santorini',
    2600,
    0,
    4.9,
    'Santorini is one of the Cyclades islands in the southern Aegean Sea. It was devastated by a volcanic eruption in the 16th century BC, and its current shape is the result of this dramatic event. Known for its dramatic views, stunning sunsets, the whitewashed cave houses, and its very own active volcano, Santorini is one of Europe\'s top destinations attracting millions of visitors each year.',
    'https://images.unsplash.com/photo-1533105079780-92b9be482077?w=600&auto=format'
  ),
  new Destination(
    '16',
    '7',
    'Acropolis of Athens',
    1500,
    -447,
    4.8,
    'The Acropolis of Athens is an ancient citadel located on a rocky outcrop above the city and contains the remains of several ancient buildings of great architectural and historic significance, the most famous being the Parthenon. The word acropolis means "high city" in Greek, and the site was in use from the Neolithic period, reaching its peak during the 5th century BCE under the leadership of Pericles.',
    'https://images.unsplash.com/photo-1555993539-1732b0258235?w=600&auto=format'
  ),

  // Thailand
  new Destination(
    '17',
    '8',
    'Grand Palace Bangkok',
    1300,
    1782,
    4.7,
    'The Grand Palace is a complex of buildings in Bangkok that has been the official residence of the Kings of Siam since 1782. The palace grounds contain the famous Temple of the Emerald Buddha (Wat Phra Kaew), recognized as the most sacred Buddhist temple in Thailand. Spanning 218,400 square meters, the complex contains more than 100 buildings that reflect Thai architectural styles spanning 200 years.',
    'https://images.unsplash.com/photo-1563492065599-3520f775eeed?w=600&auto=format'
  ),
  new Destination(
    '18',
    '8',
    'Phi Phi Islands',
    1800,
    0,
    4.8,
    'The Phi Phi Islands are an island group in Thailand, located in the Andaman Sea. The islands became famous worldwide after appearing in the 2000 film "The Beach." With their crystal-clear turquoise waters, vibrant coral reefs, dramatic limestone cliffs, and stunning beaches, the Phi Phi Islands are considered among the most beautiful islands in the world, attracting hundreds of thousands of tourists annually.',
    'https://images.unsplash.com/photo-1537956965359-7573183d1f57?w=600&auto=format'
  ),

  // Spain
  new Destination(
    '19',
    '9',
    'Sagrada Família',
    2000,
    1882,
    4.8,
    'The Sagrada Família is a large unfinished Roman Catholic minor basilica in Barcelona, designed by the Catalan architect Antoni Gaudí. Construction began in 1882 and is expected to be completed in 2026. Gaudí devoted the latter part of his life to the project, and upon his death in 1926, only about 15–25% was complete. Now a UNESCO World Heritage Site, it is Spain\'s most visited monument, drawing over 4.5 million visitors each year.',
    'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=600&auto=format'
  ),
  new Destination(
    '20',
    '9',
    'Alhambra Palace',
    1600,
    889,
    4.7,
    'The Alhambra is a palace and fortress complex located in Granada, Spain. It was originally constructed as a small fortress in 889 CE and was converted into a royal palace in 1333 by Yusuf I, Sultan of Granada. With its intricate Islamic architecture, stunning gardens, and breathtaking views over Granada, the Alhambra is one of Spain\'s greatest treasures and a UNESCO World Heritage Site.',
    'https://images.unsplash.com/photo-1558642891-54be180ea339?w=600&auto=format'
  ),

  // Canada
  new Destination(
    '21',
    '10',
    'Banff National Park',
    1900,
    1885,
    4.9,
    'Banff National Park is Canada\'s oldest national park, established in 1885, and the third-oldest national park in the world. Located in the Rocky Mountains, the park encompasses 6,641 km² of mountainous terrain with numerous glaciers and ice fields, coniferous forest, and alpine landscapes. Lake Louise, one of the world\'s most photographed lakes, with its stunning turquoise waters, is one of the park\'s highlights.',
    'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=600&auto=format'
  ),
  new Destination(
    '22',
    '10',
    'Niagara Falls',
    1200,
    0,
    4.8,
    'Niagara Falls is a group of three waterfalls at the southern end of Niagara Gorge, spanning the border between the province of Ontario in Canada and the state of New York in the United States. The largest of the three is Horseshoe Falls, also known as Canadian Falls. Combined, they form the highest flow rate of any waterfall in the world, dropping 57 meters and generating enormous amounts of hydroelectric power.',
    'https://images.unsplash.com/photo-1489447068241-b3490214e879?w=600&auto=format'
  ),

  // Mexico
  new Destination(
    '23',
    '11',
    'Chichen Itza',
    900,
    -600,
    4.8,
    'Chichen Itza was a large pre-Columbian city built by the Maya people of the Terminal Classic period. The archaeological site is located in Tinúm Municipality, Yucatán State, Mexico. Chichen Itza was the most important city of the ancient Maya and contains some of the most important monuments and temples of this civilization, including the iconic El Castillo pyramid, also known as the Temple of Kukulcan, one of the New Seven Wonders of the World.',
    'https://images.unsplash.com/photo-1518638150340-f706e86654de?w=600&auto=format'
  ),
  new Destination(
    '24',
    '11',
    'Cancun Beaches',
    1500,
    1974,
    4.6,
    'Cancun is a city in southeastern Mexico on the northeast coast of the Yucatán Peninsula in the Mexican state of Quintana Roo. It is a significant tourist destination in Mexico and one of the most popular beach resort cities in the world. Known for its pristine white sand beaches, clear turquoise Caribbean waters, vibrant nightlife, and proximity to ancient Mayan ruins, Cancun welcomes millions of international visitors each year.',
    'https://images.unsplash.com/photo-1552537376-3abf35237215?w=600&auto=format'
  ),
];
