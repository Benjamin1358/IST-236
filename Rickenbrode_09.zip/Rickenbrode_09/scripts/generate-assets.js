/**
 * generate-assets.js
 * Generates the splash screen PNG and app mockup PNG for the Vacation Destinations app.
 * Run with: node scripts/generate-assets.js
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// ─── PNG encoder (pure Node.js, no dependencies) ───────────────────────────

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

function crc32(buf, start = 0, end = buf.length) {
  let crc = 0xffffffff;
  for (let i = start; i < end; i++) crc = CRC_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const lenBuf = Buffer.alloc(4);
  lenBuf.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(td));
  return Buffer.concat([lenBuf, td, crcBuf]);
}

/**
 * Build a PNG from a pixel function getPixel(x, y) => [r, g, b].
 * Uses 8-bit RGB color (no alpha).
 */
function buildPNG(width, height, getPixel) {
  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;  // bit depth
  ihdr[9] = 2;  // color type RGB
  ihdr[10] = 0; // compression
  ihdr[11] = 0; // filter method
  ihdr[12] = 0; // interlace

  // Raw scanlines: each row prefixed by filter byte 0
  const raw = Buffer.alloc(height * (1 + width * 3));
  for (let y = 0; y < height; y++) {
    const rowOffset = y * (1 + width * 3);
    raw[rowOffset] = 0; // filter None
    for (let x = 0; x < width; x++) {
      const [r, g, b] = getPixel(x, y);
      const p = rowOffset + 1 + x * 3;
      raw[p] = r;
      raw[p + 1] = g;
      raw[p + 2] = b;
    }
  }

  const compressed = zlib.deflateSync(raw, { level: 9 });

  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), // PNG signature
    chunk('IHDR', ihdr),
    chunk('IDAT', compressed),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// ─── Drawing helpers ────────────────────────────────────────────────────────

function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

function lerp(a, b, t) {
  return Math.round(a + (b - a) * t);
}

function lerpColor(c1, c2, t) {
  return [lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t), lerp(c1[2], c2[2], t)];
}

// Creates a canvas-like pixel array
function createCanvas(width, height, fill = [255, 255, 255]) {
  const pixels = new Array(height).fill(null).map(() =>
    new Array(width).fill(null).map(() => [...fill])
  );
  return {
    width,
    height,
    getPixel: (x, y) => pixels[y][x],
    setPixel: (x, y, color) => {
      if (x >= 0 && x < width && y >= 0 && y < height) pixels[y][x] = color;
    },
    fillRect: (x, y, w, h, color) => {
      for (let dy = 0; dy < h; dy++)
        for (let dx = 0; dx < w; dx++) {
          const px = x + dx, py = y + dy;
          if (px >= 0 && px < width && py >= 0 && py < height) pixels[py][px] = color;
        }
    },
    strokeRect: (x, y, w, h, color, thickness = 2) => {
      for (let t = 0; t < thickness; t++) {
        for (let dx = 0; dx < w; dx++) {
          pixels[Math.max(0, Math.min(height - 1, y + t))][Math.max(0, Math.min(width - 1, x + dx))] = color;
          pixels[Math.max(0, Math.min(height - 1, y + h - 1 - t))][Math.max(0, Math.min(width - 1, x + dx))] = color;
        }
        for (let dy = 0; dy < h; dy++) {
          pixels[Math.max(0, Math.min(height - 1, y + dy))][Math.max(0, Math.min(width - 1, x + t))] = color;
          pixels[Math.max(0, Math.min(height - 1, y + dy))][Math.max(0, Math.min(width - 1, x + w - 1 - t))] = color;
        }
      }
    },
    fillGradientV: (x, y, w, h, colorTop, colorBottom) => {
      for (let dy = 0; dy < h; dy++) {
        const t = dy / (h - 1);
        const color = lerpColor(colorTop, colorBottom, t);
        for (let dx = 0; dx < w; dx++) {
          const px = x + dx, py = y + dy;
          if (px >= 0 && px < width && py >= 0 && py < height) pixels[py][px] = color;
        }
      }
    },
  };
}

// ─── Generate splash screen ─────────────────────────────────────────────────

function generateSplash(outPath) {
  const W = 1242, H = 2688;
  const canvas = createCanvas(W, H);

  const top = hexToRgb('#1a1a2e');
  const bot = hexToRgb('#16213e');

  // Gradient background
  canvas.fillGradientV(0, 0, W, H, top, bot);

  // Decorative circles (abstract globe)
  const cx = W / 2, cy = H / 2;
  const radii = [420, 340, 250, 160, 80];
  const ringColor = [38, 38, 80];
  for (const r of radii) {
    for (let angle = 0; angle < 360; angle += 0.5) {
      const rad = (angle * Math.PI) / 180;
      const px = Math.round(cx + r * Math.cos(rad));
      const py = Math.round(cy + r * Math.sin(rad));
      canvas.fillRect(px - 1, py - 1, 3, 3, ringColor);
    }
  }

  // Central highlighted circle
  const innerR = 70;
  for (let dy = -innerR; dy <= innerR; dy++) {
    for (let dx = -innerR; dx <= innerR; dx++) {
      if (dx * dx + dy * dy <= innerR * innerR) {
        canvas.setPixel(Math.round(cx + dx), Math.round(cy + dy), [30, 100, 200]);
      }
    }
  }

  // Title bar placeholder at top
  canvas.fillRect(W / 2 - 200, H / 2 - 200, 400, 12, [30, 100, 200]);
  canvas.fillRect(W / 2 - 140, H / 2 + 230, 280, 8, [100, 130, 200]);

  const buf = buildPNG(W, H, (x, y) => canvas.getPixel(x, y));
  fs.writeFileSync(outPath, buf);
  console.log(`✅ Splash screen written to ${outPath} (${(buf.length / 1024).toFixed(1)} KB)`);
}

// ─── Generate mockup ────────────────────────────────────────────────────────

function generateMockup(outPath) {
  const W = 1200, H = 900;
  const canvas = createCanvas(W, H);

  const bg = [240, 244, 248];
  const dark = [26, 26, 46];
  const accent = [30, 100, 200];
  const white = [255, 255, 255];
  const gray = [156, 163, 175];
  const lightGray = [229, 231, 235];
  const amber = [245, 158, 11];

  // Background
  canvas.fillRect(0, 0, W, H, bg);

  // Title banners
  canvas.fillRect(0, 0, W, 60, dark);
  canvas.fillRect(0, 0, W, 60, dark);

  // ── Screen 1: Home Screen ──────────────────────────────────────────────
  const s1x = 40, s1y = 90, s1w = 320, s1h = 700;

  // Phone frame
  canvas.fillRect(s1x, s1y, s1w, s1h, white);
  canvas.strokeRect(s1x, s1y, s1w, s1h, dark, 3);

  // App header
  canvas.fillRect(s1x, s1y, s1w, 56, dark);

  // Grid tiles (2x5 layout)
  const tileW = 130, tileH = 90, tileGap = 12;
  const tileColors = [
    [0, 49, 137], [188, 0, 45], [0, 146, 70], [178, 34, 52],
    [0, 0, 139], [0, 156, 59], [13, 94, 175], [165, 25, 49],
    [170, 21, 27], [200, 16, 46],
  ];
  let ti = 0;
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 2; col++) {
      const tx = s1x + tileGap + col * (tileW + tileGap);
      const ty = s1y + 70 + row * (tileH + tileGap);
      const c = tileColors[ti % tileColors.length];
      canvas.fillRect(tx, ty, tileW, tileH, c);
      canvas.strokeRect(tx, ty, tileW, tileH, dark, 1);
      // Label bar
      canvas.fillRect(tx, ty + tileH - 22, tileW, 22, [c[0] * 0.7, c[1] * 0.7, c[2] * 0.7].map(Math.round));
      ti++;
    }
  }

  // ── Screen 2: Destinations List ────────────────────────────────────────
  const s2x = 440, s2y = 90, s2w = 320, s2h = 700;

  canvas.fillRect(s2x, s2y, s2w, s2h, white);
  canvas.strokeRect(s2x, s2y, s2w, s2h, dark, 3);
  canvas.fillRect(s2x, s2y, s2w, 56, dark);

  // Destination cards
  for (let i = 0; i < 4; i++) {
    const cy2 = s2y + 70 + i * 140;
    // Card background
    canvas.fillRect(s2x + 12, cy2, s2w - 24, 128, white);
    canvas.strokeRect(s2x + 12, cy2, s2w - 24, 128, lightGray, 1);
    // Image placeholder
    canvas.fillRect(s2x + 12, cy2, 110, 128, accent);
    // Name bar
    canvas.fillRect(s2x + 132, cy2 + 10, 150, 14, dark);
    // Detail rows
    canvas.fillRect(s2x + 132, cy2 + 36, 80, 8, gray);
    canvas.fillRect(s2x + 230, cy2 + 36, 60, 8, dark);
    canvas.fillRect(s2x + 132, cy2 + 56, 80, 8, gray);
    canvas.fillRect(s2x + 230, cy2 + 56, 60, 8, dark);
    canvas.fillRect(s2x + 132, cy2 + 76, 80, 8, gray);
    canvas.fillRect(s2x + 230, cy2 + 76, 60, 8, amber);
  }

  // ── Screen 3: Modal ────────────────────────────────────────────────────
  const s3x = 840, s3y = 90, s3w = 320, s3h = 700;

  canvas.fillRect(s3x, s3y, s3w, s3h, white);
  canvas.strokeRect(s3x, s3y, s3w, s3h, dark, 3);

  // Large image at top
  canvas.fillRect(s3x, s3y, s3w, 220, accent);

  // Stats row
  canvas.fillRect(s3x + 12, s3y + 232, s3w - 24, 70, dark);
  // Stat items
  for (let s = 0; s < 3; s++) {
    const sx = s3x + 30 + s * 100;
    canvas.fillRect(sx, s3y + 250, 60, 8, gray);
    canvas.fillRect(sx, s3y + 270, 70, 12, white);
    if (s < 2) canvas.fillRect(sx + 88, s3y + 244, 2, 40, [55, 65, 81]);
  }

  // Description lines
  for (let l = 0; l < 5; l++) {
    canvas.fillRect(s3x + 16, s3y + 320 + l * 22, s3w - 80 + (l === 4 ? -40 : 0), 10, lightGray);
  }

  // Close button
  canvas.fillRect(s3x + 16, s3y + 640, s3w - 32, 48, dark);
  canvas.fillRect(s3x + s3w / 2 - 40, s3y + 658, 80, 12, white);

  // ── Screen labels ──────────────────────────────────────────────────────
  const labelY = s1y + s1h + 20;

  // Label rectangles
  canvas.fillRect(s1x + 50, labelY, 220, 36, dark);
  canvas.fillRect(s2x + 50, labelY, 220, 36, dark);
  canvas.fillRect(s3x + 50, labelY, 220, 36, dark);

  // ── Top banner text area ────────────────────────────────────────────────
  canvas.fillRect(W / 2 - 280, 12, 560, 20, white);
  canvas.fillRect(W / 2 - 160, 36, 320, 12, [100, 130, 200]);

  // Legend strip at bottom
  canvas.fillRect(0, H - 40, W, 40, dark);

  const buf = buildPNG(W, H, (x, y) => canvas.getPixel(x, y));
  fs.writeFileSync(outPath, buf);
  console.log(`✅ Mockup written to ${outPath} (${(buf.length / 1024).toFixed(1)} KB)`);
}

// ─── Main ───────────────────────────────────────────────────────────────────

const root = path.resolve(__dirname, '..');

const splashDir = path.join(root, 'assets', 'images');
if (!fs.existsSync(splashDir)) fs.mkdirSync(splashDir, { recursive: true });

const docsDir = path.join(root, 'docs');
if (!fs.existsSync(docsDir)) fs.mkdirSync(docsDir, { recursive: true });

generateSplash(path.join(splashDir, 'splash.png'));
generateMockup(path.join(docsDir, 'app_mockup.png'));
