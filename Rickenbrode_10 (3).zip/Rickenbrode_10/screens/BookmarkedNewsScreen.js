import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

function BookmarkedNewsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bookmarked News</Text>
      <Text style={styles.subtitle}>This page is intentionally left empty this week.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff9f0',
    padding: 20,
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: '#1f3a5f',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#4e5f78',
    textAlign: 'center',
  },
});

export default BookmarkedNewsScreen;
