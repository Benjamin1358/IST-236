import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

import List from '../components/List';

function TechNewsScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tech Pulse</Text>
      <List category="tech" navigation={navigation} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff9f0',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1f3a5f',
    marginTop: 14,
    marginLeft: 16,
  },
});

export default TechNewsScreen;
