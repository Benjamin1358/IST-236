import React from 'react';
import { View, ActivityIndicator } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { useFonts } from 'expo-font';

import UsNewsScreen from './screens/UsNewsScreen';
import WorldNewsScreen from './screens/WorldNewsScreen';
import TechNewsScreen from './screens/TechNewsScreen';
import BookmarkedNewsScreen from './screens/BookmarkedNewsScreen';
import NewsDetailScreen from './screens/NewsDetailScreen';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();
const Tabs = createBottomTabNavigator();

function NewsTabsNavigator() {
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => ({
        headerStyle: { backgroundColor: '#1f3a5f' },
        headerTintColor: '#fff',
        tabBarStyle: { backgroundColor: '#f5efe6' },
        tabBarActiveTintColor: '#1f3a5f',
        tabBarInactiveTintColor: '#6a7a93',
        tabBarIcon: ({ color, size }) => {
          let iconName = 'newspaper-outline';

          if (route.name === 'US News') iconName = 'flag-outline';
          if (route.name === 'World News') iconName = 'earth-outline';
          if (route.name === 'Tech News') iconName = 'hardware-chip-outline';

          return <Ionicons name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tabs.Screen name="US News" component={UsNewsScreen} />
      <Tabs.Screen name="World News" component={WorldNewsScreen} />
      <Tabs.Screen name="Tech News" component={TechNewsScreen} />
    </Tabs.Navigator>
  );
}

function NewsDrawerNavigator() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#1f3a5f' },
        headerTintColor: '#fff',
        drawerActiveTintColor: '#1f3a5f',
        drawerInactiveTintColor: '#51617a',
      }}
    >
      <Drawer.Screen
        name="News Categories"
        component={NewsTabsNavigator}
        options={{
          drawerIcon: ({ color, size }) => (
            <Ionicons name="newspaper-outline" size={size} color={color} />
          ),
        }}
      />
      <Drawer.Screen
        name="Bookmarked News"
        component={BookmarkedNewsScreen}
        options={{
          drawerIcon: ({ color, size }) => (
            <Ionicons name="bookmark-outline" size={size} color={color} />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
  });

  if (!fontsLoaded) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#f5efe6',
        }}
      >
        <ActivityIndicator size="large" color="#1f3a5f" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#1f3a5f' },
          headerTintColor: '#fff',
          contentStyle: { backgroundColor: '#fff9f0' },
        }}
      >
        <Stack.Screen
          name="News Drawer"
          component={NewsDrawerNavigator}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="News Detail"
          component={NewsDetailScreen}
          options={{ title: 'News Detail' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
