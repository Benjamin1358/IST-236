import React from 'react';
import { FlatList, View, Text, StyleSheet } from 'react-native';

import NEWS_DATA from '../data/dummy-data';
import ListItem from './ListItem';

function List({ category, navigation }) {
  const items = NEWS_DATA.filter((item) => item.category === category);

  if (!items.length) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>No news found in this category.</Text>
      </View>
    );
  }

  return (
    <FlatList
      data={items}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <ListItem
          item={item}
          onPress={() => navigation.navigate('News Detail', { newsId: item.id })}
        />
      )}
      contentContainerStyle={styles.listContent}
    />
  );
}

const styles = StyleSheet.create({
  listContent: {
    paddingVertical: 10,
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  emptyText: {
    color: '#44536b',
    fontSize: 16,
  },
});

export default List;
