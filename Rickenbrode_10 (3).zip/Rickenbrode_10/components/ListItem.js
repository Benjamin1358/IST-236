import React from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';

function ListItem({ item, onPress }) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: '#d9e1ed' }}
      style={({ pressed }) => [styles.card, pressed && styles.pressed]}
    >
      <Image source={{ uri: item.imageUrl }} style={styles.image} />
      <View style={styles.infoContainer}>
        <Text style={styles.headline} numberOfLines={2}>
          {item.headline}
        </Text>
        <Text style={styles.date}>{item.date}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    borderRadius: 14,
    marginVertical: 8,
    marginHorizontal: 14,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.16,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
  },
  pressed: {
    opacity: 0.86,
  },
  image: {
    width: '100%',
    height: 170,
  },
  infoContainer: {
    padding: 12,
    gap: 4,
  },
  headline: {
    fontSize: 18,
    fontWeight: '700',
    color: '#18304f',
  },
  date: {
    fontSize: 13,
    color: '#5f6f86',
  },
});

export default ListItem;
