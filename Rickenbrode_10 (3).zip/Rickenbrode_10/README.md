# Rickenbrode_10 News App

This React Native (Expo) project includes:

- Top-level native stack navigator with:
  - Drawer navigator screen
  - News Detail screen
- Drawer navigator with:
  - Tab navigator
  - Bookmarked News screen (intentionally empty this week)
- Bottom tab navigator with:
  - US News screen
  - World News screen
  - Tech News screen
- Custom reusable `List` and `ListItem` components
- Dummy data sourced from a model
- News Detail screen with a header bookmark button toggle
- App waits for fonts (Ionicons font) to load before rendering

## Run

1. Install dependencies:
   - `npm install`
2. Start app:
   - `npm run start`

## Submission Checklist (Instructor Requirements)

- [x] App mockup image stored in `docs/` as PNG
- [x] `node_modules` excluded via `.gitignore` and should be removed before zipping
- [ ] Zip local project folder as `lastname_10.zip`
- [ ] Upload zip to D2L dropbox
- [ ] Push project folder to your public GitHub class repository
- [ ] Include your GitHub repository link in your submission
