import News from '../models/News';

const NEWS_DATA = [
  new News(
    'n1',
    'Senate Passes New Infrastructure Package in Bipartisan Vote',
    '2026-03-31',
    'Maya Rodriguez',
    'CNN',
    'Lawmakers approved a wide-ranging infrastructure bill targeting bridges, water systems, and broadband expansion after weeks of negotiations.',
    'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=1200&q=80',
    'us'
  ),
  new News(
    'n2',
    'Severe Storm System Sweeps Across Midwest, Thousands Without Power',
    '2026-03-30',
    'James Parker',
    'Fox News',
    'Emergency crews continue restoration work after overnight storms damaged homes and knocked out service across multiple states.',
    'https://images.unsplash.com/photo-1594156596782-656c93e4d504?auto=format&fit=crop&w=1200&q=80',
    'us'
  ),
  new News(
    'n3',
    'Global Climate Summit Opens With New Emissions Targets',
    '2026-04-01',
    'Aisha Khan',
    'BBC',
    'Delegates from over 100 countries gathered to negotiate updated carbon reduction pledges and climate financing commitments.',
    'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80',
    'world'
  ),
  new News(
    'n4',
    'Ceasefire Talks Resume as Regional Leaders Meet in Geneva',
    '2026-03-29',
    'Leo Martin',
    'Reuters',
    'Diplomats returned to the table with international mediators expressing cautious optimism about narrowing key disagreements.',
    'https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?auto=format&fit=crop&w=1200&q=80',
    'world'
  ),
  new News(
    'n5',
    'Major Smartphone Maker Unveils AI-Powered Personal Assistant',
    '2026-03-31',
    'Nina Patel',
    'The Verge',
    'The company introduced new on-device features designed to summarize messages, schedule tasks, and improve privacy controls.',
    'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1200&q=80',
    'tech'
  ),
  new News(
    'n6',
    'Quantum Computing Startup Secures Record Funding Round',
    '2026-03-28',
    'Ethan Cole',
    'TechCrunch',
    'Investors backed the startup to accelerate development of next-generation processors aimed at logistics and biotech use cases.',
    'https://images.unsplash.com/photo-1555255707-c07966088b7b?auto=format&fit=crop&w=1200&q=80',
    'tech'
  ),
];

export default NEWS_DATA;
