# NutriTrack Calorie Tracker (IST 236 Milestone 2)

## Overview
NutriTrack is a health and fitness mobile app that helps users log meals, track calories, and monitor nutrition progress.

## Milestone 2 Status
This submission includes the core app structure with all required screens built and accessible through bottom tab navigation:

- Home
- Food Log
- Progress
- Profile

The app starts without crashing and each screen contains meaningful layout/components.

## Implemented Requirements

### Navigation and Core Setup
- React Navigation (Bottom Tabs)
- NavigationContainer
- SafeAreaProvider
- StatusBar component

### Styling and UI
- Central theme constants file: src/constants/theme.js
- Responsive layout support using flexible dimensions and orientation handling
- Custom fonts (Montserrat and Lato via Expo Google Fonts)
- Splash screen behavior through an app startup gate component
- Clean, non-overlapping screen layouts

### Concepts Implemented (8+)
1. TextInput components with validation (Food Log, Profile)
2. Linking and web-loaded image (Profile external link + Home background image)
3. useMemo hook (derived totals and list data)
4. useEffect hook (splash timer, orientation listener)
5. Alert API usage (validation/success/failure messages)
6. Icons (tab bar via Ionicons)
7. Switch component (dark mode toggle)
8. LinearGradient background (home hero and splash)
9. Modal component (Food Log entry details)
10. FlatList component (logged food entries)
11. Multiple orientation support (Progress screen)
12. App-wide state management with Context API
13. HTTP request (OpenFoodFacts calorie suggestion)

## Project Structure
- App.js
- app.json
- src/navigation/RootNavigator.js
- src/context/NutriContext.js
- src/constants/theme.js
- src/components/SplashGate.js
- src/screens/HomeScreen.js
- src/screens/FoodLogScreen.js
- src/screens/ProgressScreen.js
- src/screens/ProfileScreen.js

## Run Locally
1. npm install
2. npm start
3. Press "a" for Android emulator/device, or scan QR with Expo Go

## Submission Reminder
Before submitting your milestone zip:
1. Delete node_modules folder
2. Zip the full project directory
3. Name zip as lastname_IST236_milestone2
4. Include your GitHub repository link in D2L submission
