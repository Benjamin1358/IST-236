export const palette = {
  light: {
    bg: "#f4f8ff",
    card: "#ffffff",
    text: "#18212f",
    muted: "#667085",
    accent: "#0b74de",
    accentAlt: "#00a86b",
    border: "#d4deec",
    danger: "#d64545",
  },
  dark: {
    bg: "#121923",
    card: "#1a2432",
    text: "#eef3fb",
    muted: "#9eb1c8",
    accent: "#5aa6ff",
    accentAlt: "#30c58d",
    border: "#2f435f",
    danger: "#ff6f6f",
  },
};

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 24,
  xl: 32,
};

export const radius = {
  sm: 8,
  md: 14,
  lg: 20,
};

export const getTheme = (darkMode) => {
  const colors = darkMode ? palette.dark : palette.light;

  return {
    colors,
    spacing,
    radius,
    font: {
      heading: "Montserrat_700Bold",
      body: "Lato_400Regular",
      bodyBold: "Lato_700Bold",
    },
  };
};
