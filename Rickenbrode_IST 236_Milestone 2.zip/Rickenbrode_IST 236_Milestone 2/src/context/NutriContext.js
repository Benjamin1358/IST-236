import React, { createContext, useContext, useMemo, useState } from "react";

const NutriContext = createContext(null);

const initialEntries = [
  { id: "1", name: "Chicken", calories: 300, date: new Date().toISOString() },
  { id: "2", name: "Apple", calories: 95, date: new Date().toISOString() },
];

export function NutriProvider({ children }) {
  const [entries, setEntries] = useState(initialEntries);
  const [profile, setProfile] = useState({
    name: "",
    calorieGoal: 2000,
    darkMode: false,
  });

  const addEntry = (name, calories) => {
    const next = {
      id: `${Date.now()}`,
      name,
      calories,
      date: new Date().toISOString(),
    };
    setEntries((prev) => [next, ...prev]);
  };

  const value = useMemo(
    () => ({
      entries,
      profile,
      addEntry,
      setProfile,
    }),
    [entries, profile]
  );

  return <NutriContext.Provider value={value}>{children}</NutriContext.Provider>;
}

export function useNutri() {
  const ctx = useContext(NutriContext);
  if (!ctx) {
    throw new Error("useNutri must be used within NutriProvider");
  }
  return ctx;
}
