import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import HomeScreen from "../screens/HomeScreen";
import FoodLogScreen from "../screens/FoodLogScreen";
import ProgressScreen from "../screens/ProgressScreen";
import ProfileScreen from "../screens/ProfileScreen";
import { useNutri } from "../context/NutriContext";
import { getTheme } from "../constants/theme";

const Tab = createBottomTabNavigator();

const iconByRoute = {
  Home: "home",
  "Food Log": "fast-food",
  Progress: "stats-chart",
  Profile: "person",
};

export default function RootNavigator() {
  const { profile } = useNutri();
  const theme = getTheme(profile.darkMode);

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: theme.colors.accent,
        tabBarInactiveTintColor: theme.colors.muted,
        tabBarStyle: {
          backgroundColor: theme.colors.card,
          borderTopColor: theme.colors.border,
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontFamily: theme.font.bodyBold,
          fontSize: 12,
        },
        tabBarIcon: ({ color, size }) => (
          <Ionicons name={iconByRoute[route.name]} size={size} color={color} />
        ),
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Food Log" component={FoodLogScreen} />
      <Tab.Screen name="Progress" component={ProgressScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}
