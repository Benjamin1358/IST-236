import React, { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

export default function SplashGate({ ready, children }) {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    if (!ready) {
      return;
    }
    const timer = setTimeout(() => setShowSplash(false), 1400);
    return () => clearTimeout(timer);
  }, [ready]);

  if (showSplash || !ready) {
    return (
      <LinearGradient colors={["#0b74de", "#00a86b"]} style={styles.container}>
        <Text style={styles.title}>NutriTrack</Text>
        <Text style={styles.subtitle}>Track smarter. Eat better.</Text>
      </LinearGradient>
    );
  }

  return children;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  title: {
    color: "#ffffff",
    fontSize: 48,
    fontFamily: "Montserrat_700Bold",
  },
  subtitle: {
    marginTop: 10,
    color: "#e8f4ff",
    fontSize: 18,
    fontFamily: "Lato_400Regular",
  },
});
