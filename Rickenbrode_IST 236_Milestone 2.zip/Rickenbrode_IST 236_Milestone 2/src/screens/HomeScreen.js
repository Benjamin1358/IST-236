import React, { useMemo } from "react";
import { ImageBackground, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { useNutri } from "../context/NutriContext";
import { getTheme } from "../constants/theme";

export default function HomeScreen({ navigation }) {
  const { entries, profile } = useNutri();
  const theme = getTheme(profile.darkMode);

  const consumed = useMemo(
    () => entries.reduce((sum, item) => sum + Number(item.calories || 0), 0),
    [entries]
  );

  const goal = Number(profile.calorieGoal || 2000);
  const remaining = Math.max(goal - consumed, 0);
  const progress = Math.min(consumed / goal, 1);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.colors.bg }]}>
      <ImageBackground
        source={{
          uri: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=1200&q=60",
        }}
        resizeMode="cover"
        style={styles.hero}
      >
        <LinearGradient colors={["rgba(6,16,35,0.45)", "rgba(6,16,35,0.75)"]} style={styles.overlay}>
          <Text style={[styles.heading, { fontFamily: theme.font.heading }]}>Daily Snapshot</Text>
          <Text style={[styles.sub, { fontFamily: theme.font.body }]}>Stay on track with simple meal logging.</Text>
        </LinearGradient>
      </ImageBackground>

      <View style={[styles.card, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]}>
        <Text style={[styles.rowLabel, { color: theme.colors.muted, fontFamily: theme.font.bodyBold }]}>Daily Calories</Text>
        <Text style={[styles.rowValue, { color: theme.colors.text, fontFamily: theme.font.heading }]}>{goal} kcal</Text>

        <Text style={[styles.rowLabel, { color: theme.colors.muted, fontFamily: theme.font.bodyBold }]}>Calories Remaining</Text>
        <Text style={[styles.rowValue, { color: theme.colors.text, fontFamily: theme.font.heading }]}>{remaining} kcal</Text>

        <View style={[styles.barTrack, { backgroundColor: theme.colors.border }]}>
          <View
            style={[
              styles.barFill,
              {
                width: `${Math.round(progress * 100)}%`,
                backgroundColor: theme.colors.accentAlt,
              },
            ]}
          />
        </View>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: theme.colors.accent }]}
          onPress={() => navigation.navigate("Food Log")}
          activeOpacity={0.9}
        >
          <Text style={[styles.buttonText, { fontFamily: theme.font.bodyBold }]}>Add Food</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  hero: {
    height: 220,
    margin: 16,
    borderRadius: 20,
    overflow: "hidden",
  },
  overlay: {
    flex: 1,
    justifyContent: "flex-end",
    padding: 16,
  },
  heading: {
    color: "#ffffff",
    fontSize: 30,
  },
  sub: {
    marginTop: 6,
    color: "#dde8f8",
    fontSize: 15,
  },
  card: {
    marginHorizontal: 16,
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
  },
  rowLabel: {
    fontSize: 15,
    marginTop: 4,
  },
  rowValue: {
    fontSize: 27,
    marginBottom: 6,
  },
  barTrack: {
    height: 12,
    borderRadius: 999,
    overflow: "hidden",
    marginVertical: 12,
  },
  barFill: {
    height: "100%",
  },
  button: {
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: "center",
    marginTop: 8,
  },
  buttonText: {
    color: "#ffffff",
    fontSize: 16,
  },
});
