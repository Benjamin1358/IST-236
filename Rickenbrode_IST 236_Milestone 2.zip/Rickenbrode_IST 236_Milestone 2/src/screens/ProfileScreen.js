import React, { useState } from "react";
import { Alert, Linking, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNutri } from "../context/NutriContext";
import { getTheme } from "../constants/theme";

export default function ProfileScreen() {
  const { profile, setProfile } = useNutri();
  const theme = getTheme(profile.darkMode);
  const [name, setName] = useState(profile.name);
  const [goal, setGoal] = useState(String(profile.calorieGoal));

  const saveProfile = () => {
    const parsedGoal = Number(goal);
    if (!name.trim()) {
      Alert.alert("Name required", "Please enter your name.");
      return;
    }
    if (!Number.isFinite(parsedGoal) || parsedGoal < 1000) {
      Alert.alert("Goal too low", "Please enter a goal of at least 1000 calories.");
      return;
    }

    setProfile((prev) => ({
      ...prev,
      name: name.trim(),
      calorieGoal: Math.round(parsedGoal),
    }));
    Alert.alert("Saved", "Your profile settings were updated.");
  };

  const openResource = async () => {
    const url = "https://www.myplate.gov/";
    const supported = await Linking.canOpenURL(url);
    if (supported) {
      await Linking.openURL(url);
    } else {
      Alert.alert("Link error", "Could not open the nutrition resource.");
    }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.colors.bg }]}>
      <View style={[styles.card, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]}> 
        <Text style={[styles.heading, { color: theme.colors.text, fontFamily: theme.font.heading }]}>Profile</Text>

        <Text style={[styles.label, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>Name</Text>
        <TextInput
          value={name}
          onChangeText={setName}
          placeholder="Enter Name"
          placeholderTextColor={theme.colors.muted}
          style={[
            styles.input,
            {
              borderColor: theme.colors.border,
              color: theme.colors.text,
              fontFamily: theme.font.body,
            },
          ]}
        />

        <Text style={[styles.label, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>Calorie Goal</Text>
        <TextInput
          value={goal}
          onChangeText={setGoal}
          keyboardType="number-pad"
          placeholder="Enter Goal"
          placeholderTextColor={theme.colors.muted}
          style={[
            styles.input,
            {
              borderColor: theme.colors.border,
              color: theme.colors.text,
              fontFamily: theme.font.body,
            },
          ]}
        />

        <View style={styles.switchRow}>
          <Text style={[styles.label, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>Dark Mode</Text>
          <Switch
            value={profile.darkMode}
            onValueChange={(value) => setProfile((prev) => ({ ...prev, darkMode: value }))}
            thumbColor={profile.darkMode ? theme.colors.accentAlt : "#f7f7f7"}
            trackColor={{ true: theme.colors.accent, false: theme.colors.border }}
          />
        </View>

        <TouchableOpacity style={[styles.saveBtn, { backgroundColor: theme.colors.accent }]} onPress={saveProfile}>
          <Text style={[styles.saveText, { fontFamily: theme.font.bodyBold }]}>Save</Text>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.linkBtn, { borderColor: theme.colors.border }]} onPress={openResource}>
          <Text style={[styles.linkText, { color: theme.colors.accent, fontFamily: theme.font.bodyBold }]}>Open Nutrition Guide</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    padding: 16,
  },
  card: {
    borderWidth: 1,
    borderRadius: 20,
    padding: 16,
  },
  heading: {
    fontSize: 28,
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 4,
    marginTop: 4,
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
    fontSize: 16,
    marginBottom: 8,
  },
  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 10,
  },
  saveBtn: {
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 12,
    marginTop: 4,
  },
  saveText: {
    color: "#ffffff",
    fontSize: 16,
  },
  linkBtn: {
    marginTop: 10,
    borderWidth: 1,
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 12,
  },
  linkText: {
    fontSize: 15,
  },
});
