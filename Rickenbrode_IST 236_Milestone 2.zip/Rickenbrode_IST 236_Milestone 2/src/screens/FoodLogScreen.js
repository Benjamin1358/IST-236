import React, { useMemo, useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNutri } from "../context/NutriContext";
import { getTheme } from "../constants/theme";

export default function FoodLogScreen() {
  const { entries, profile, addEntry } = useNutri();
  const theme = getTheme(profile.darkMode);
  const [foodName, setFoodName] = useState("");
  const [calories, setCalories] = useState("");
  const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState(null);

  const listData = useMemo(() => entries, [entries]);

  const validateInput = () => {
    const parsedCalories = Number(calories);
    if (!foodName.trim()) {
      Alert.alert("Missing food name", "Please enter a meal or food item name.");
      return null;
    }
    if (!Number.isFinite(parsedCalories) || parsedCalories <= 0) {
      Alert.alert("Invalid calories", "Calories must be a positive number.");
      return null;
    }
    return parsedCalories;
  };

  const handleAddEntry = () => {
    const parsedCalories = validateInput();
    if (!parsedCalories) {
      return;
    }
    addEntry(foodName.trim(), parsedCalories);
    setFoodName("");
    setCalories("");
    Alert.alert("Entry added", "Your meal has been logged.");
  };

  const loadCaloriesSuggestion = async () => {
    if (!foodName.trim()) {
      Alert.alert("Enter food first", "Type a food name before fetching suggestions.");
      return;
    }

    setIsLoadingSuggestion(true);
    try {
      const query = encodeURIComponent(foodName.trim());
      const res = await fetch(
        `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${query}&search_simple=1&json=1&page_size=1`
      );
      const data = await res.json();
      const candidate = data?.products?.[0];
      const foundCalories = candidate?.nutriments?.["energy-kcal_100g"];

      if (foundCalories) {
        setCalories(String(Math.round(foundCalories)));
        Alert.alert("Suggestion loaded", "Calories were filled from OpenFoodFacts.");
      } else {
        Alert.alert("No calorie data", "Try adding calories manually for this item.");
      }
    } catch (err) {
      Alert.alert("Request failed", "Could not fetch nutrition data right now.");
    } finally {
      setIsLoadingSuggestion(false);
    }
  };

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.colors.bg }]}>
      <View style={[styles.card, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]}>
        <Text style={[styles.label, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>Food Name</Text>
        <TextInput
          value={foodName}
          onChangeText={setFoodName}
          placeholder="Enter Food"
          placeholderTextColor={theme.colors.muted}
          style={[
            styles.input,
            {
              borderColor: theme.colors.border,
              color: theme.colors.text,
              fontFamily: theme.font.body,
            },
          ]}
        />

        <Text style={[styles.label, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>Calories</Text>
        <TextInput
          value={calories}
          onChangeText={setCalories}
          keyboardType="number-pad"
          placeholder="Enter Calories"
          placeholderTextColor={theme.colors.muted}
          style={[
            styles.input,
            {
              borderColor: theme.colors.border,
              color: theme.colors.text,
              fontFamily: theme.font.body,
            },
          ]}
        />

        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: theme.colors.accent }]}
            onPress={handleAddEntry}
            activeOpacity={0.9}
          >
            <Text style={[styles.buttonText, { fontFamily: theme.font.bodyBold }]}>Add Entry</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: theme.colors.accentAlt }]}
            onPress={loadCaloriesSuggestion}
            activeOpacity={0.9}
          >
            <Text style={[styles.buttonText, { fontFamily: theme.font.bodyBold }]}>
              {isLoadingSuggestion ? "Loading..." : "Auto Fill"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={[styles.listCard, { backgroundColor: theme.colors.card, borderColor: theme.colors.border }]}>
        <Text style={[styles.title, { color: theme.colors.text, fontFamily: theme.font.heading }]}>Food List</Text>

        <FlatList
          data={listData}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.item, { borderBottomColor: theme.colors.border }]}
              onPress={() => setSelectedEntry(item)}
            >
              <Text style={[styles.itemName, { color: theme.colors.text, fontFamily: theme.font.bodyBold }]}>
                {item.name}
              </Text>
              <Text style={[styles.itemMeta, { color: theme.colors.muted, fontFamily: theme.font.body }]}>
                {item.calories} cal
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <Modal visible={!!selectedEntry} transparent animationType="slide" onRequestClose={() => setSelectedEntry(null)}>
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalCard, { backgroundColor: theme.colors.card }]}> 
            <Text style={[styles.modalTitle, { color: theme.colors.text, fontFamily: theme.font.heading }]}>
              Entry Details
            </Text>
            <Text style={[styles.modalLine, { color: theme.colors.text, fontFamily: theme.font.body }]}> 
              Food: {selectedEntry?.name}
            </Text>
            <Text style={[styles.modalLine, { color: theme.colors.text, fontFamily: theme.font.body }]}> 
              Calories: {selectedEntry?.calories}
            </Text>
            <TouchableOpacity
              style={[styles.closeBtn, { backgroundColor: theme.colors.accent }]}
              onPress={() => setSelectedEntry(null)}
            >
              <Text style={[styles.buttonText, { fontFamily: theme.font.bodyBold }]}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  card: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 14,
    marginTop: 8,
  },
  label: {
    marginTop: 4,
    marginBottom: 6,
    fontSize: 15,
  },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: 8,
    fontSize: 16,
  },
  buttonRow: {
    flexDirection: "row",
    gap: 10,
  },
  button: {
    flex: 1,
    alignItems: "center",
    borderRadius: 10,
    paddingVertical: 11,
    marginTop: 4,
  },
  buttonText: {
    color: "#ffffff",
    fontSize: 15,
  },
  listCard: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 18,
    marginTop: 12,
    padding: 14,
  },
  title: {
    fontSize: 22,
    marginBottom: 6,
  },
  listContent: {
    paddingBottom: 24,
  },
  item: {
    borderBottomWidth: 1,
    paddingVertical: 10,
  },
  itemName: {
    fontSize: 16,
  },
  itemMeta: {
    marginTop: 2,
    fontSize: 14,
  },
  modalBackdrop: {
    flex: 1,
    justifyContent: "flex-end",
    backgroundColor: "rgba(0,0,0,0.4)",
  },
  modalCard: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 18,
  },
  modalTitle: {
    fontSize: 24,
    marginBottom: 10,
  },
  modalLine: {
    fontSize: 16,
    marginBottom: 6,
  },
  closeBtn: {
    marginTop: 10,
    borderRadius: 10,
    alignItems: "center",
    paddingVertical: 12,
  },
});
