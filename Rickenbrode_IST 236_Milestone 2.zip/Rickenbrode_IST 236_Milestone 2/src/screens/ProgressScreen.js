import React, { useEffect, useMemo, useState } from "react";
import { Dimensions, StyleSheet, Text, useWindowDimensions, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNutri } from "../context/NutriContext";
import { getTheme } from "../constants/theme";

const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function ProgressScreen() {
  const { entries, profile } = useNutri();
  const theme = getTheme(profile.darkMode);
  const { width, height } = useWindowDimensions();
  const isLandscape = width > height;
  const [layout, setLayout] = useState(Dimensions.get("window"));

  useEffect(() => {
    const sub = Dimensions.addEventListener("change", ({ window }) => {
      setLayout(window);
    });
    return () => sub.remove();
  }, []);

  const weekly = useMemo(() => {
    const bucket = {};
    for (const item of entries) {
      const day = dayNames[new Date(item.date).getDay()];
      bucket[day] = (bucket[day] || 0) + Number(item.calories || 0);
    }
    return dayNames.map((day) => ({ day, calories: bucket[day] || 0 }));
  }, [entries]);

  const maxVal = Math.max(...weekly.map((d) => d.calories), 100);

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: theme.colors.bg }]}>
      <View
        style={[
          styles.wrapper,
          {
            backgroundColor: theme.colors.card,
            borderColor: theme.colors.border,
            flexDirection: isLandscape ? "row" : "column",
          },
        ]}
      >
        <View style={[styles.left, isLandscape && { flex: 1.2 }]}> 
          <Text style={[styles.title, { color: theme.colors.text, fontFamily: theme.font.heading }]}>Weekly Summary</Text>
          {weekly.map((item) => (
            <Text key={item.day} style={[styles.line, { color: theme.colors.text, fontFamily: theme.font.body }]}>
              {item.day}: {item.calories} kcal
            </Text>
          ))}
          <Text style={[styles.dimMeta, { color: theme.colors.muted, fontFamily: theme.font.body }]}> 
            Layout: {Math.round(layout.width)} x {Math.round(layout.height)}
          </Text>
        </View>

        <View style={[styles.chart, isLandscape && { flex: 1 }]}> 
          {weekly.map((item) => (
            <View key={item.day} style={styles.barWrap}>
              <View style={[styles.barTrack, { backgroundColor: theme.colors.border }]}>
                <View
                  style={[
                    styles.bar,
                    {
                      backgroundColor: theme.colors.accent,
                      height: `${Math.max((item.calories / maxVal) * 100, 6)}%`,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.barLabel, { color: theme.colors.muted, fontFamily: theme.font.bodyBold }]}>
                {item.day}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    padding: 16,
  },
  wrapper: {
    flex: 1,
    borderRadius: 20,
    borderWidth: 1,
    padding: 14,
    gap: 10,
  },
  left: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    marginBottom: 8,
  },
  line: {
    fontSize: 16,
    marginBottom: 6,
  },
  dimMeta: {
    marginTop: 10,
    fontSize: 14,
  },
  chart: {
    minHeight: 200,
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingHorizontal: 8,
    gap: 8,
  },
  barWrap: {
    flex: 1,
    alignItems: "center",
  },
  barTrack: {
    width: "90%",
    height: 140,
    borderRadius: 10,
    justifyContent: "flex-end",
    overflow: "hidden",
  },
  bar: {
    width: "100%",
    borderRadius: 10,
  },
  barLabel: {
    marginTop: 6,
    fontSize: 13,
  },
});
