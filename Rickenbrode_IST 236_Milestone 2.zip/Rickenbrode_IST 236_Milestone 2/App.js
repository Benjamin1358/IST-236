import React from "react";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useFonts } from "expo-font";
import { Montserrat_700Bold } from "@expo-google-fonts/montserrat";
import { Lato_400Regular, Lato_700Bold } from "@expo-google-fonts/lato";
import { NutriProvider, useNutri } from "./src/context/NutriContext";
import RootNavigator from "./src/navigation/RootNavigator";
import SplashGate from "./src/components/SplashGate";
import { getTheme } from "./src/constants/theme";

function AppShell() {
  const { profile } = useNutri();
  const theme = getTheme(profile.darkMode);

  const navTheme = {
    ...DefaultTheme,
    colors: {
      ...DefaultTheme.colors,
      background: theme.colors.bg,
      card: theme.colors.card,
      text: theme.colors.text,
      border: theme.colors.border,
      primary: theme.colors.accent,
    },
  };

  return (
    <NavigationContainer theme={navTheme}>
      <StatusBar style={profile.darkMode ? "light" : "dark"} />
      <RootNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  const [fontsLoaded] = useFonts({
    Montserrat_700Bold,
    Lato_400Regular,
    Lato_700Bold,
  });

  return (
    <SafeAreaProvider>
      <NutriProvider>
        <SplashGate ready={fontsLoaded}>
          <AppShell />
        </SplashGate>
      </NutriProvider>
    </SafeAreaProvider>
  );
}
